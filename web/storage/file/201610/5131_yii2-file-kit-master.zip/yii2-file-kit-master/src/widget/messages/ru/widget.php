<?php
/**
 * Project yii2-file-kit.
 * Author: Eugene Terentev <eugene@terentev.net>
 */
return [
    'Maximum number of files exceeded' => 'Достигнуто максимальное кол-во файлов',
    'File type not allowed' => 'Тип файла не разрешен',
    'File is too large' => 'Файл слишком большой',
    'File is too small' => 'Файл меньше минимального размера'
];